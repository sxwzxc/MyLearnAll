#include "Rectangle2.h"

Rectangle2::Rectangle2() {}

Rectangle2::~Rectangle2() {}

void Rectangle2::showName()
{
    cout << Shape::ProtectData << endl;
}
