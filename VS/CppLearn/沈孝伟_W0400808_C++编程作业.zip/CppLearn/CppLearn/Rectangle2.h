#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include "Shape.h"
class Rectangle2 :
    private Shape
{
public:
    Rectangle2();
    ~Rectangle2();
    void showName();
};

